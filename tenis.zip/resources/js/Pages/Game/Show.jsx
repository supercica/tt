import React from 'react';

function Show(props) {
    return (
        <div></div>
    );
}

export default Show;
